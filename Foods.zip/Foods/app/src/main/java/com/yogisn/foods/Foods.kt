package com.yogisn.foods

data class Foods(
    var name: String = "",
    var detail: String = "",
    var gambar: Int = 0
)